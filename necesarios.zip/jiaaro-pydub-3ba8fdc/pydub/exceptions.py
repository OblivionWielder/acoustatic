

class TooManyMissingFrames(Exception):
    pass


class InvalidDuration(Exception):
    pass
